/* Source and licensing information for the line(s) below can be found at http://localhost/SBHS-D10/core/assets/vendor/jquery.ui/ui/form-min.js. */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],t):t(jQuery)}((function(t){"use strict";return t.fn._form=function(){return"string"==typeof this[0].form?this.closest("form"):t(this[0].form)}}));
//# sourceMappingURL=form-min.js.map
/* Source and licensing information for the above line(s) can be found at http://localhost/SBHS-D10/core/assets/vendor/jquery.ui/ui/form-min.js. */