/* Source and licensing information for the line(s) below can be found at http://localhost/SBHS-D10/themes/openplc/js/nav.js. */
// $( '#openplc_nav .navbar-nav a' ).on( 'click', function () {
// 	$( '#openplc_nav .navbar-nav' ).find( 'li.active' ).removeClass( 'active' );
// 	$( this ).parent( 'li' ).addClass( 'active' );
// // });


/* Source and licensing information for the above line(s) can be found at http://localhost/SBHS-D10/themes/openplc/js/nav.js. */