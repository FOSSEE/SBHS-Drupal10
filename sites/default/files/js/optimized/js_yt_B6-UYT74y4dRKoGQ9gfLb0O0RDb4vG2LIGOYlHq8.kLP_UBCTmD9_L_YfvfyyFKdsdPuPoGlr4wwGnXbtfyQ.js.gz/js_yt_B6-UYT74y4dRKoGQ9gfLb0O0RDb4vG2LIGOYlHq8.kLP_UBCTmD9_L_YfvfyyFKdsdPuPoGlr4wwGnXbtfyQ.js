/* Source and licensing information for the line(s) below can be found at http://localhost/SBHS-D10/core/assets/vendor/jquery.ui/ui/scroll-parent-min.js. */
/*!
 * jQuery UI Scroll Parent 1.13.2
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],t):t(jQuery)}((function(t){"use strict";return t.fn.scrollParent=function(e){var s=this.css("position"),n="absolute"===s,o=e?/(auto|scroll|hidden)/:/(auto|scroll)/,i=this.parents().filter((function(){var e=t(this);return(!n||"static"!==e.css("position"))&&o.test(e.css("overflow")+e.css("overflow-y")+e.css("overflow-x"))})).eq(0);return"fixed"!==s&&i.length?i:t(this[0].ownerDocument||document)}}));
//# sourceMappingURL=scroll-parent-min.js.map
/* Source and licensing information for the above line(s) can be found at http://localhost/SBHS-D10/core/assets/vendor/jquery.ui/ui/scroll-parent-min.js. */