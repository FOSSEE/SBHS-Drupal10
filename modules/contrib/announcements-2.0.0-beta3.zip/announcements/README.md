# Announcements

This module provides an Announcement entity type and functionality for managing
the display of announcements.
