
         $(window).load(function() {
       $('#slideshow').orbit({
             bullets: false,
             timer: true,
             captions: true,
	     animationSpeed: 1000,
	     pauseOnHover: true,
	     startClockOnMouseOut:true,
             captionAnimation: 'fade',
             animation: 'fade' });
   });


