$(document).ready(function(){
$('#main-menu ul li').hover(function(){
    $(this).addClass('hover');
  }, function(){
    $(this).removeClass('hover');
  });
});
