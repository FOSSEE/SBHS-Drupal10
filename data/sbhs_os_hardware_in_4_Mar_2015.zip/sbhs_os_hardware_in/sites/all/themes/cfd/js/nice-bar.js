$(document).ready(function() {                                                  
    $(".nice-bar").slideDown();                                                 
    $(".nice-close").click(function() {                                         
	$(".nice-bar").slideUp();                                               
    });                                                                         
});
